package com.example.proyectomusikalia.ui

import com.example.proyectomusikalia.data.Song

data class MusikaliaUiState(
    val song: Song? = null
)

package com.example.proyectomusikalia

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.proyectomusikalia.data.songBandaSonora
import com.example.proyectomusikalia.screens.Cancion
import com.example.proyectomusikalia.screens.MusikaliaApp
import com.example.proyectomusikalia.ui.theme.ProyectoMusikaliaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val navController = rememberNavController()
            ProyectoMusikaliaTheme {
                NavHost(navController = navController, startDestination = "Pantalla Principal" ) {
                    composable("Pantalla Principal") {
                      MusikaliaApp()
                    }
                    composable("Pantalla Cancion") {
                        Cancion()
                    }
                }
            }
        }
    }
}


package com.example.proyectomusikalia.screens

enum class Pantallas {
    Pantalla_Principal, Pantalla_Cancion
}